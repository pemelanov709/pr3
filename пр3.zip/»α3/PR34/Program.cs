﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR34
{
    class SmsMessage
    {

        private string messagetxt;
        private double firstprice;
        private double secondprice;
        private int maxlenghtmsg;

        public string MessageText { set { messagetxt = CheckLongMess(value); } }
        public double Price { get { return MsgPrice(messagetxt); } }
        public double FirstPrice { set { firstprice = value; } }
        public double SecondPrice { set { secondprice = value; } }
        public int MaxLenghtMsg {set { maxlenghtmsg = value; } }

        //аргументоы
        public SmsMessage(double fprice, double sprice, int msxlnght)
        {
            FirstPrice = fprice;
            SecondPrice = sprice;
            MaxLenghtMsg = msxlnght;
        }

        //Перегрузка без аргументов, свойства = обычные
        public SmsMessage()
        {
            FirstPrice = 1.5;
            SecondPrice = 0.5;
            MaxLenghtMsg = 250;
        }

        //проверкиа длинны сообщения
        private string CheckLongMess(string msg1)
        {
            if (msg1.Length > maxlenghtmsg)
            {
                return msg1.Substring(0, msg1.Length - (msg1.Length - maxlenghtmsg));
            }
            else {
                return msg1;
                    }
        }

        //расчёт цены сообщения
        private double MsgPrice(string msg2)
        {
            if (msg2.Length < 65)
            {
                return msg2.Length * firstprice;
            }
            return msg2.Length * secondprice;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("sms любому человеку до 250 символов." +
                "\nТарифы:" +
                "\nиспользуйте старые или введите свои" +
                "\nСообщения < 65 символов стоят 1.5;" +
                "\nСообщения > 65 символов стоят 0.5 рублей." +
                "\nВведите ваш ответ (С(старый)/В(ввод)): ");

            //Ввод выбора тарифа
            char answ = char.Parse(Console.ReadLine());

            //Ввод sms
            Console.WriteLine("Введите ваше сообщение:");
            string msg = Console.ReadLine();

            if(answ == 'С' | answ == 'с')
            {
                SmsMessage smstext = new SmsMessage();
                smstext.MessageText = msg;

                Console.Write($"\nЦена сообщения: {smstext.Price}");
            }
            else if(answ == 'В' | answ == 'в')
            {
                Console.Write("Введите вашу цену для сообщения до 65 символов, после 65 символов и максимальную длину сообщения: ");

                string srv = Console.ReadLine();
                string[] num = srv.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                SmsMessage smstext = new SmsMessage(Convert.ToDouble(num[0]), Convert.ToDouble(num[1]), Convert.ToInt32(num[2]));
                smstext.MessageText = msg;

                //Вывод
                Console.Write($"\nЦена сообщения: {smstext.Price}");
            }
            Console.ReadKey(true);
        }
    }
}
