﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR33
{
    class MyIntList
    {
        private List<int> numberList = new List<int>();

        public double Average
        {
            get
            {
                return CalculateAverage();

            }
        }

        //Ввод массива чисел
        public void AddNumberRange(int[] numbers)
        {
            numberList.AddRange(numbers);
        }

        //Ввод одного значения в список
        public void AddNumber(int number)
        {
            numberList.Add(number);
        }

        //Удаление одного значения в списке
        public void RemoveNumber(int number)
        {
            numberList.Remove(number);
        }

        //Расчёт среднего арифметического
        private double CalculateAverage()
        {
            int sum = 0;
            foreach (int number in numberList)
            {
                sum += number;
            }
            return sum / (double)numberList.Count;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
                MyIntList numbers = new MyIntList();

            Console.Write("Введите ваши числа: ");

                numbers.AddNumberRange(new[] { 1,2,3,4});
                Console.WriteLine(numbers.Average);
        }
    }
}
